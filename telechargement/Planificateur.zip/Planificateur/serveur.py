#!/usr/bin/env python3
"""
Planificateur — publication multi-plateformes : YouTube, Instagram (Reels) et TikTok.

Application locale : un petit serveur tourne sur ton Mac et une page web
(http://localhost:8765) te permet d'importer une vidéo une seule fois,
d'écrire les textes, puis de publier partout en un clic.

Aucune dépendance : uniquement la bibliothèque standard de Python 3.
Lancement :  python3 serveur.py   (ou double-clic sur « Lancer.command »)
"""
from __future__ import annotations

import hashlib
import http.client
import http.server
import json
import mimetypes
import os
import re
import secrets
import struct
import subprocess
import sys
import threading
import time
import traceback
import urllib.parse
import uuid
import webbrowser
from datetime import datetime
from pathlib import Path

PORT = int(os.environ.get("PORT", "8765"))
HOTE = "127.0.0.1"
BASE = Path(__file__).resolve().parent
INTERFACE = BASE / "interface"
DONNEES = BASE / "donnees"
FICHIERS = DONNEES / "fichiers"
CONFIG_F = DONNEES / "config.json"
JETONS_F = DONNEES / "jetons.json"
HISTO_F = DONNEES / "historique.json"

IG_VERSION = "v23.0"
EXT_VIDEO = {".mp4", ".mov", ".m4v", ".webm"}
EXT_IMAGE = {".jpg", ".jpeg", ".png"}
CONSERVATION_FICHIERS_JOURS = 14

PLATEFORMES = ("youtube", "instagram", "tiktok")


class ErreurPlateforme(Exception):
    pass


# ---------------------------------------------------------------------------
# Stockage local (fichiers JSON lisibles uniquement par ton utilisateur)
# ---------------------------------------------------------------------------
_verrou = threading.Lock()


def lire(fichier: Path, defaut):
    try:
        return json.loads(fichier.read_text("utf-8"))
    except (OSError, ValueError):
        return defaut


def ecrire(fichier: Path, obj) -> None:
    with _verrou:
        DONNEES.mkdir(parents=True, exist_ok=True)
        tmp = fichier.with_suffix(".tmp")
        tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), "utf-8")
        os.chmod(tmp, 0o600)
        tmp.replace(fichier)


def config() -> dict:
    return lire(CONFIG_F, {})


def jetons() -> dict:
    return lire(JETONS_F, {})


def maj_jetons(plateforme: str, valeurs) -> None:
    j = jetons()
    if valeurs is None:
        j.pop(plateforme, None)
    else:
        j[plateforme] = valeurs
    ecrire(JETONS_F, j)


# ---------------------------------------------------------------------------
# Requêtes HTTP (http.client pour garder la main sur les codes 308, etc.)
# ---------------------------------------------------------------------------
def requete(methode, url, entetes=None, corps=None, timeout=120):
    u = urllib.parse.urlsplit(url)
    Conn = http.client.HTTPSConnection if u.scheme == "https" else http.client.HTTPConnection
    conn = Conn(u.netloc, timeout=timeout)
    chemin = (u.path or "/") + ("?" + u.query if u.query else "")
    try:
        conn.request(methode, chemin, body=corps, headers=entetes or {})
        r = conn.getresponse()
        contenu = r.read()
        return r.status, {k.lower(): v for k, v in r.getheaders()}, contenu
    finally:
        conn.close()


def requete_json(methode, url, entetes=None, json_corps=None, form=None, timeout=120):
    h = dict(entetes or {})
    corps = None
    if json_corps is not None:
        corps = json.dumps(json_corps).encode("utf-8")
        h["Content-Type"] = "application/json; charset=UTF-8"
    elif form is not None:
        corps = urllib.parse.urlencode(form).encode("utf-8")
        h["Content-Type"] = "application/x-www-form-urlencoded"
    st, hd, b = requete(methode, url, h, corps, timeout)
    try:
        data = json.loads(b.decode("utf-8") or "{}")
    except ValueError:
        data = {"_brut": b.decode("utf-8", "replace")[:500]}
    return st, hd, data


def msg_erreur(d) -> str:
    if not isinstance(d, dict):
        return str(d)[:300]
    e = d.get("error")
    if isinstance(e, dict):
        txt = e.get("error_user_msg") or e.get("message") or e.get("code") or json.dumps(e)
        code = e.get("code")
        return f"{txt} ({code})" if code and str(code) not in str(txt) else str(txt)
    if isinstance(e, str):
        return d.get("error_description") or e
    return d.get("message") or d.get("_brut") or json.dumps(d)[:300]


class LecteurProgression:
    """Enveloppe un fichier pour suivre la progression d'un envoi en flux."""

    def __init__(self, f, taille, rappel):
        self.f, self.taille, self.rappel, self.lu = f, taille, rappel, 0

    def read(self, n=-1):
        bloc = self.f.read(n if n and n > 0 else 1024 * 1024)
        self.lu += len(bloc)
        self.rappel(self.lu / max(self.taille, 1))
        return bloc


def type_mime(chemin: Path) -> str:
    return {".mov": "video/quicktime", ".m4v": "video/mp4", ".webm": "video/webm"}.get(
        chemin.suffix.lower(), mimetypes.guess_type(str(chemin))[0] or "video/mp4"
    )


# ---------------------------------------------------------------------------
# Connexions OAuth
# ---------------------------------------------------------------------------
ETATS_OAUTH: dict = {}


APP_TIKTOK_F = BASE / "tiktok_app.json"  # identifiants de l'app TikTok fournis avec l'outil


def app_tiktok() -> dict:
    """Identifiants de l'app TikTok : ceux saisis dans l'onglet Comptes, sinon ceux fournis avec l'outil.

    Sans adresse de retour https personnalisée, on utilise la connexion « bureau » de TikTok
    (retour sur localhost + PKCE), prévue pour les applications installées sur l'ordinateur.
    """
    c = config()
    fournie = lire(APP_TIKTOK_F, {})
    if c.get("tiktok_client_key") and c.get("tiktok_client_secret"):
        cle, secret = c["tiktok_client_key"], c["tiktok_client_secret"]
    else:
        cle, secret = fournie.get("client_key", ""), fournie.get("client_secret", "")
    relais = (c.get("tiktok_redirect_uri") or "").strip()
    return {"cle": cle, "secret": secret, "bureau": not relais,
            "redirect": relais or f"http://localhost:{PORT}/oauth/tiktok/",
            "fournie": bool(fournie.get("client_key")),
            "audite": bool(c.get("tiktok_audite") or fournie.get("audite"))}


def redirect_uri(plateforme: str) -> str:
    if plateforme == "tiktok":
        return app_tiktok()["redirect"]
    return f"http://localhost:{PORT}/oauth/{plateforme}"


def nouvel_etat(plateforme: str, extra=None) -> str:
    etat = secrets.token_urlsafe(24)
    ETATS_OAUTH[etat] = (plateforme, time.time() + 900, extra)
    return etat


def verifier_etat(etat: str, plateforme: str):
    p, expire, extra = ETATS_OAUTH.pop(etat or "", (None, 0, None))
    if p != plateforme or expire < time.time():
        raise ErreurPlateforme("Lien de connexion expiré ou invalide : recommence la connexion.")
    return extra


# --- YouTube ---------------------------------------------------------------
def url_auth_youtube() -> str:
    c = config()
    if not c.get("youtube_client_id") or not c.get("youtube_client_secret"):
        raise ErreurPlateforme("Renseigne d'abord l'ID client et le secret Google.")
    q = {
        "client_id": c["youtube_client_id"],
        "redirect_uri": redirect_uri("youtube"),
        "response_type": "code",
        "scope": "https://www.googleapis.com/auth/youtube.upload "
                 "https://www.googleapis.com/auth/youtube.readonly",
        "access_type": "offline",
        "prompt": "consent",
        "state": nouvel_etat("youtube"),
    }
    return "https://accounts.google.com/o/oauth2/v2/auth?" + urllib.parse.urlencode(q)


def echanger_code_youtube(code: str) -> None:
    c = config()
    st, _, d = requete_json("POST", "https://oauth2.googleapis.com/token", form={
        "code": code,
        "client_id": c["youtube_client_id"],
        "client_secret": c["youtube_client_secret"],
        "redirect_uri": redirect_uri("youtube"),
        "grant_type": "authorization_code",
    })
    if st != 200 or "access_token" not in d:
        raise ErreurPlateforme("Google a refusé la connexion : " + msg_erreur(d))
    jeton = {
        "access_token": d["access_token"],
        "refresh_token": d.get("refresh_token"),
        "expire": time.time() + int(d.get("expires_in", 3600)),
    }
    st, _, ch = requete_json("GET", "https://www.googleapis.com/youtube/v3/channels?part=snippet&mine=true",
                             {"Authorization": "Bearer " + jeton["access_token"]})
    items = ch.get("items") or []
    jeton["compte"] = items[0]["snippet"]["title"] if items else "Chaîne YouTube"
    maj_jetons("youtube", jeton)


def jeton_youtube() -> str:
    j = jetons().get("youtube")
    if not j:
        raise ErreurPlateforme("YouTube n'est pas connecté.")
    if j["expire"] - 120 > time.time():
        return j["access_token"]
    c = config()
    st, _, d = requete_json("POST", "https://oauth2.googleapis.com/token", form={
        "client_id": c.get("youtube_client_id", ""),
        "client_secret": c.get("youtube_client_secret", ""),
        "refresh_token": j.get("refresh_token") or "",
        "grant_type": "refresh_token",
    })
    if st != 200 or "access_token" not in d:
        raise ErreurPlateforme("Session YouTube expirée, reconnecte le compte. (" + msg_erreur(d) + ")")
    j["access_token"] = d["access_token"]
    j["expire"] = time.time() + int(d.get("expires_in", 3600))
    maj_jetons("youtube", j)
    return j["access_token"]


# --- TikTok ----------------------------------------------------------------
def url_auth_tiktok() -> str:
    a = app_tiktok()
    if not a["cle"] or not a["secret"]:
        raise ErreurPlateforme("Les identifiants de l'app TikTok sont introuvables : réinstalle le Planificateur "
                               "ou renseigne-les dans l'onglet Comptes (réglages avancés).")
    q = {
        "client_key": a["cle"],
        "response_type": "code",
        "scope": "user.info.basic,video.publish,video.upload",
        "redirect_uri": a["redirect"],
    }
    verificateur = None
    if a["bureau"]:
        # PKCE version TikTok : le « challenge » est le SHA-256 du vérificateur, encodé en hexadécimal.
        verificateur = secrets.token_urlsafe(48)[:64]
        q["code_challenge"] = hashlib.sha256(verificateur.encode("ascii")).hexdigest()
        q["code_challenge_method"] = "S256"
    q["state"] = nouvel_etat("tiktok", verificateur)
    return "https://www.tiktok.com/v2/auth/authorize/?" + urllib.parse.urlencode(q)


def _enregistrer_jeton_tiktok(d: dict, ancien=None) -> dict:
    jeton = dict(ancien or {})
    jeton.update({
        "access_token": d["access_token"],
        "refresh_token": d.get("refresh_token", jeton.get("refresh_token")),
        "expire": time.time() + int(d.get("expires_in", 86400)),
        "open_id": d.get("open_id", jeton.get("open_id")),
        "scope": d.get("scope", jeton.get("scope", "")),
    })
    return jeton


def echanger_code_tiktok(code: str, verificateur=None) -> None:
    a = app_tiktok()
    formulaire = {
        "client_key": a["cle"],
        "client_secret": a["secret"],
        "code": code,
        "grant_type": "authorization_code",
        "redirect_uri": a["redirect"],
    }
    if verificateur:
        formulaire["code_verifier"] = verificateur
    st, _, d = requete_json("POST", "https://open.tiktokapis.com/v2/oauth/token/", form=formulaire)
    if st != 200 or "access_token" not in d:
        raise ErreurPlateforme("TikTok a refusé la connexion : " + msg_erreur(d))
    jeton = _enregistrer_jeton_tiktok(d)
    st, _, u = requete_json("GET", "https://open.tiktokapis.com/v2/user/info/?fields=display_name",
                            {"Authorization": "Bearer " + jeton["access_token"]})
    jeton["compte"] = ((u.get("data") or {}).get("user") or {}).get("display_name") or "Compte TikTok"
    maj_jetons("tiktok", jeton)


def jeton_tiktok() -> str:
    j = jetons().get("tiktok")
    if not j:
        raise ErreurPlateforme("TikTok n'est pas connecté.")
    if j["expire"] - 300 > time.time():
        return j["access_token"]
    c = config()
    st, _, d = requete_json("POST", "https://open.tiktokapis.com/v2/oauth/token/", form={
        "client_key": app_tiktok()["cle"],
        "client_secret": app_tiktok()["secret"],
        "grant_type": "refresh_token",
        "refresh_token": j.get("refresh_token") or "",
    })
    if st != 200 or "access_token" not in d:
        raise ErreurPlateforme("Session TikTok expirée, reconnecte le compte. (" + msg_erreur(d) + ")")
    j = _enregistrer_jeton_tiktok(d, j)
    maj_jetons("tiktok", j)
    return j["access_token"]


def infos_createur_tiktok() -> dict:
    st, _, d = requete_json("POST", "https://open.tiktokapis.com/v2/post/publish/creator_info/query/",
                            {"Authorization": "Bearer " + jeton_tiktok()}, json_corps={})
    if (d.get("error") or {}).get("code") not in (None, "ok"):
        raise ErreurPlateforme(msg_erreur(d))
    return d.get("data") or {}


# --- Instagram -------------------------------------------------------------
FB_GRAPH = f"https://graph.facebook.com/{IG_VERSION}"


def connecter_instagram_facebook(token: str) -> None:
    """Jeton « connexion Facebook » (EAA…) : on le rend permanent via la Page reliée au compte Instagram."""
    c = config()
    app_id, secret = c.get("meta_app_id"), c.get("meta_app_secret")
    if not app_id or not secret:
        raise ErreurPlateforme("Pour un jeton Facebook (EAA…), renseigne d'abord l'ID et la clé secrète "
                               "de l'app Meta, puis clique sur Enregistrer.")
    # 1. Jeton court (1 h) -> jeton long (60 jours)
    st, _, d = requete_json("GET", f"{FB_GRAPH}/oauth/access_token?" + urllib.parse.urlencode({
        "grant_type": "fb_exchange_token", "client_id": app_id,
        "client_secret": secret, "fb_exchange_token": token}))
    if st != 200 or not d.get("access_token"):
        raise ErreurPlateforme("Meta a refusé le jeton : " + msg_erreur(d) +
                               " — vérifie l'ID et la clé secrète de l'app, et génère un nouveau jeton.")
    long_terme = d["access_token"]
    # 2. Jeton de Page (permanent) + compte Instagram relié à la Page
    st, _, d = requete_json("GET", f"{FB_GRAPH}/me/accounts?" + urllib.parse.urlencode({
        "fields": "name,access_token,instagram_business_account{id,username}",
        "limit": "100", "access_token": long_terme}))
    if st != 200:
        raise ErreurPlateforme("Impossible de lire tes Pages Facebook : " + msg_erreur(d))
    pages = [p for p in d.get("data", []) if p.get("instagram_business_account")]
    if not pages:
        raise ErreurPlateforme("Aucune Page Facebook reliée à un compte Instagram professionnel n'a été trouvée. "
                               "Relie ton compte Instagram à une Page, puis génère un nouveau jeton en cochant cette Page.")
    page = pages[0]
    ig = page["instagram_business_account"]
    maj_jetons("instagram", {
        "mode": "facebook",
        "access_token": page["access_token"],
        "user_id": str(ig["id"]),
        "compte": "@" + ig.get("username", "instagram"),
        "page": page.get("name"),
        "renouvele": time.time(),
    })


def connecter_instagram(token: str) -> None:
    token = token.strip()
    if token.startswith("EAA"):
        return connecter_instagram_facebook(token)
    st, _, d = requete_json("GET", f"https://graph.instagram.com/{IG_VERSION}/me?" +
                            urllib.parse.urlencode({"fields": "user_id,username", "access_token": token}))
    if st != 200 or not (d.get("user_id") or d.get("id")):
        raise ErreurPlateforme("Jeton Instagram refusé : " + msg_erreur(d))
    maj_jetons("instagram", {
        "access_token": token,
        "user_id": str(d.get("user_id") or d.get("id")),
        "compte": "@" + d.get("username", "instagram"),
        "renouvele": time.time(),
    })


def jeton_instagram() -> dict:
    j = jetons().get("instagram")
    if not j:
        raise ErreurPlateforme("Instagram n'est pas connecté.")
    # Les jetons longue durée (60 jours) se renouvellent : on le fait chaque semaine.
    # (Les jetons de Page obtenus via Facebook n'expirent pas : rien à faire.)
    if j.get("mode") != "facebook" and time.time() - j.get("renouvele", 0) > 7 * 86400:
        st, _, d = requete_json("GET", "https://graph.instagram.com/refresh_access_token?" +
                                urllib.parse.urlencode({"grant_type": "ig_refresh_token",
                                                        "access_token": j["access_token"]}))
        if st == 200 and d.get("access_token"):
            j["access_token"] = d["access_token"]
            j["renouvele"] = time.time()
            maj_jetons("instagram", j)
    return j


# ---------------------------------------------------------------------------
# Traduction (DeepL) pour les titres et descriptions YouTube
# ---------------------------------------------------------------------------
# Code de langue YouTube -> (code DeepL, nom affiché)
LANGUES = {
    "en": ("EN-US", "Anglais"),
    "es": ("ES", "Espagnol"),
    "de": ("DE", "Allemand"),
    "it": ("IT", "Italien"),
    "pt-BR": ("PT-BR", "Portugais (Brésil)"),
    "nl": ("NL", "Néerlandais"),
    "pl": ("PL", "Polonais"),
    "ru": ("RU", "Russe"),
    "tr": ("TR", "Turc"),
    "ar": ("AR", "Arabe"),
    "ja": ("JA", "Japonais"),
    "ko": ("KO", "Coréen"),
    "zh-CN": ("ZH-HANS", "Chinois (simplifié)"),
}

_RE_HASHTAG = re.compile(r"#[\wÀ-ɏ]+")


def _proteger(texte: str) -> str:
    """Échappe le texte pour DeepL (mode XML) et protège les hashtags de la traduction."""
    texte = texte.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return _RE_HASHTAG.sub(lambda m: f"<x>{m.group(0)}</x>", texte)


# Mentions du type « Traduit avec DeepL » / « Translated with www.DeepL.com/Translator (free version) »,
# dans les langues proposées : elles ne doivent jamais apparaître dans une publication.
_MOTS_TRADUIT = (r"traduit|traduction|translated|translation|übersetzt|übersetzung|traducido|traducción|"
                 r"tradotto|traduzione|traduzido|tradução|vertaald|vertaling|przetłumaczon\w*|tłumaczenie|"
                 r"переведено|перевод|çevril\w*|çeviri|ترجم\w*|翻訳|번역|翻译|翻譯")
_RE_MENTION_DEEPL = re.compile(
    r"[\(\[]?[^\S\n]*(?:(?:" + _MOTS_TRADUIT + r")[^\n]{0,40}?)?"   # « Traduit avec » (facultatif)
    r"(?:https?://)?(?:www\.)?deepl(?:\.com)?(?:/[\w/.-]*)?"           # DeepL / www.DeepL.com/Translator
    r"(?:[^\S\n]*[\(\[][^\n\)\]]{0,40}[\)\]])?"                        # « (version gratuite) »
    r"[^\S\n]*[\)\]]?",
    re.IGNORECASE)


def sans_mention_deepl(texte):
    """Retire toute mention de DeepL d'un texte destiné à être publié."""
    if not texte:
        return texte
    lignes = []
    for ligne in texte.split("\n"):
        if "deepl" not in ligne.lower():
            lignes.append(ligne)
            continue
        reste = re.sub(r"[^\S\n]{2,}", " ", _RE_MENTION_DEEPL.sub("", ligne)).strip(" \t-–—|•·:")
        # Ce qui reste n'est que la fin de la mention (« で翻訳しました », « ile çevrildi »…) : on retire la ligne.
        if len(reste) < 3 or re.fullmatch(r"\W*\w{0,4}\W*(?:" + _MOTS_TRADUIT + r")\w*\W*", reste, re.IGNORECASE) \
                or re.match(r"^\W{0,3}\w{0,4}(?:" + _MOTS_TRADUIT + r")", reste, re.IGNORECASE):
            continue
        lignes.append(reste)
    if len(lignes) == len(texte.split("\n")) and "\n".join(lignes) == texte:
        return texte  # aucune mention : le texte reste strictement identique
    propre = re.sub(r"\n{3,}", "\n\n", "\n".join(lignes))
    return propre.strip()


def _restaurer(texte: str) -> str:
    texte = texte.replace("<x>", "").replace("</x>", "")
    return texte.replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&")


def traduire(titre: str, description: str, langues: list) -> dict:
    cle = (config().get("deepl_api_key") or "").strip()
    if not cle:
        raise ErreurPlateforme("Ajoute d'abord ta clé DeepL dans l'onglet Comptes.")
    hotes = ["api-free.deepl.com", "api.deepl.com"]
    if not cle.endswith(":fx"):
        hotes.reverse()
    resultat = {}
    for code in langues:
        if code not in LANGUES:
            continue
        corps = {
            "text": [_proteger(titre), _proteger(description)],
            "source_lang": "FR",
            "target_lang": LANGUES[code][0],
            "tag_handling": "xml",
            "ignore_tags": ["x"],
            "split_sentences": "nonewlines",
            "preserve_formatting": True,
        }
        st, _, d = requete_json("POST", f"https://{hotes[0]}/v2/translate",
                                {"Authorization": "DeepL-Auth-Key " + cle}, json_corps=corps)
        if st == 403:
            # Selon le forfait, la clé dépend de l'une ou l'autre adresse : on essaie l'autre,
            # et on la garde pour les langues suivantes si elle fonctionne.
            st2, _, d2 = requete_json("POST", f"https://{hotes[1]}/v2/translate",
                                      {"Authorization": "DeepL-Auth-Key " + cle}, json_corps=corps)
            if st2 != 403:
                st, d = st2, d2
                hotes.reverse()
        if st == 403:
            raise ErreurPlateforme("Clé DeepL refusée : vérifie-la dans l'onglet Comptes.")
        if st == 456:
            raise ErreurPlateforme("Quota DeepL du mois atteint : les traductions reprendront le mois prochain.")
        if st != 200 or len(d.get("translations") or []) != 2:
            raise ErreurPlateforme(f"DeepL n'a pas pu traduire en {LANGUES[code][1].lower()} : " + msg_erreur(d))
        t, desc = (sans_mention_deepl(_restaurer(x["text"])) for x in d["translations"])
        resultat[code] = {"titre": t.strip()[:100], "description": desc.strip()[:5000]}
    return resultat


# ---------------------------------------------------------------------------
# Publication
# ---------------------------------------------------------------------------
TACHES: dict = {}


def maj(tache: dict, plateforme: str, **valeurs) -> None:
    tache["plateformes"][plateforme].update(valeurs)


def chemin_fichier(ident: str) -> Path:
    nom = Path(ident or "").name
    chemin = FICHIERS / nom
    if not nom or not chemin.is_file():
        raise ErreurPlateforme("Fichier introuvable : réimporte la vidéo.")
    return chemin


def publier_youtube(tache: dict, p: dict) -> None:
    yt = p["youtube"]
    video = chemin_fichier(p["video"])
    taille = video.stat().st_size
    jeton = jeton_youtube()
    maj(tache, "youtube", message="Création de la vidéo sur YouTube…")
    statut = {
        "privacyStatus": yt.get("visibilite") or "private",
        "selfDeclaredMadeForKids": bool(yt.get("pour_enfants")),
        "embeddable": True,
    }
    if yt.get("programmation"):
        statut["privacyStatus"] = "private"
        statut["publishAt"] = yt["programmation"]
    meta = {
        "snippet": {
            "title": (sans_mention_deepl(yt.get("titre")) or "Sans titre")[:100],
            "description": (sans_mention_deepl(yt.get("description")) or "")[:5000],
            "tags": [t for t in (yt.get("tags") or []) if t][:30],
            "categoryId": str(yt.get("categorie") or "22"),
        },
        "status": statut,
    }
    parties = "snippet,status"
    traductions = {code: {"titre": sans_mention_deepl(t.get("titre") or ""),
                          "description": sans_mention_deepl(t.get("description") or "")}
                   for code, t in (yt.get("traductions") or {}).items() if code in LANGUES}
    traductions = {code: t for code, t in traductions.items() if t["titre"].strip()}
    if traductions:
        # Le titre et la description de base sont en français ; YouTube affiche
        # automatiquement la version traduite selon la langue du spectateur.
        meta["snippet"]["defaultLanguage"] = "fr"
        meta["localizations"] = {code: {"title": t["titre"].strip()[:100],
                                        "description": t["description"][:5000]}
                                 for code, t in traductions.items()}
        parties += ",localizations"
    st, hd, d = requete_json(
        "POST",
        "https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=" + parties,
        {"Authorization": "Bearer " + jeton,
         "X-Upload-Content-Type": type_mime(video),
         "X-Upload-Content-Length": str(taille)},
        json_corps=meta,
    )
    if st != 200 or "location" not in hd:
        raise ErreurPlateforme("YouTube a refusé l'envoi : " + msg_erreur(d))
    url_envoi = hd["location"]

    bloc = 8 * 1024 * 1024  # multiple de 256 Kio, exigé par YouTube
    debut, echecs, video_id = 0, 0, None
    with open(video, "rb") as f:
        while video_id is None:
            f.seek(debut)
            morceau = f.read(bloc)
            fin = debut + len(morceau) - 1
            try:
                st, hd, b = requete("PUT", url_envoi,
                                    {"Content-Range": f"bytes {debut}-{fin}/{taille}"}, morceau, timeout=600)
            except (OSError, http.client.HTTPException):
                st, hd, b = 0, {}, b""
            if st == 308:
                plage = hd.get("range")
                debut = int(plage.split("-")[1]) + 1 if plage else 0
                echecs = 0
            elif st in (200, 201):
                video_id = json.loads(b.decode("utf-8"))["id"]
                debut = taille
            elif st == 0 or st >= 500:
                echecs += 1
                if echecs > 6:
                    raise ErreurPlateforme("Connexion perdue pendant l'envoi vers YouTube.")
                time.sleep(2 ** echecs)
                # On demande à YouTube où il en est avant de reprendre.
                try:
                    st2, hd2, _ = requete("PUT", url_envoi, {"Content-Range": f"bytes */{taille}"}, b"")
                    if st2 == 308:
                        plage = hd2.get("range")
                        debut = int(plage.split("-")[1]) + 1 if plage else 0
                except (OSError, http.client.HTTPException):
                    pass
            else:
                try:
                    err = json.loads(b.decode("utf-8"))
                except ValueError:
                    err = {"_brut": b.decode("utf-8", "replace")}
                raise ErreurPlateforme("Envoi YouTube interrompu : " + msg_erreur(err))
            maj(tache, "youtube", progression=round(90 * debut / max(taille, 1)),
                message=f"Envoi de la vidéo… {round(100 * debut / max(taille, 1))} %")

    lien = f"https://youtu.be/{video_id}"
    maj(tache, "youtube", lien=lien, progression=92)
    avert = []
    if p.get("miniature"):
        maj(tache, "youtube", message="Ajout de la miniature…")
        image = chemin_fichier(p["miniature"])
        if image.stat().st_size > 2 * 1024 * 1024:
            avert.append("miniature non ajoutée : elle dépasse 2 Mo")
        else:
            st, d = envoyer_miniature(
                f"https://www.googleapis.com/upload/youtube/v3/thumbnails/set?videoId={video_id}",
                jeton_youtube(), image)
            if st != 200:
                avert.append("miniature refusée (" + msg_erreur(d) +
                             ") — vérifie que ta chaîne est validée par téléphone")
    msg = "Publiée sur YouTube"
    if traductions:
        msg += f" avec {len(traductions)} traduction" + ("s" if len(traductions) > 1 else "")
    if statut["privacyStatus"] != "public":
        msg += " (" + {"private": "privée", "unlisted": "non répertoriée"}[statut["privacyStatus"]] + ")"
    if avert:
        msg += " — " + "; ".join(avert)
    maj(tache, "youtube", etat="avertissement" if avert else "termine", progression=100, message=msg)


def envoyer_miniature(url, jeton, image: Path):
    ct = "image/png" if image.suffix.lower() == ".png" else "image/jpeg"
    st, _, b = requete("POST", url, {"Authorization": "Bearer " + jeton, "Content-Type": ct},
                       image.read_bytes(), timeout=120)
    try:
        return st, json.loads(b.decode("utf-8") or "{}")
    except ValueError:
        return st, {"_brut": b.decode("utf-8", "replace")}


def publier_instagram(tache: dict, p: dict) -> None:
    ig = p["instagram"]
    j = jeton_instagram()
    token, uid = j["access_token"], j["user_id"]
    video = chemin_fichier(p["video"])
    taille = video.stat().st_size
    base = FB_GRAPH if j.get("mode") == "facebook" else f"https://graph.instagram.com/{IG_VERSION}"

    maj(tache, "instagram", message="Création du Reel…")
    params = {
        "media_type": "REELS",
        "upload_type": "resumable",
        "caption": (sans_mention_deepl(ig.get("legende")) or "")[:2200],
        "share_to_feed": "true" if ig.get("partager_fil", True) else "false",
        "access_token": token,
    }
    if ig.get("couverture_url"):
        params["cover_url"] = ig["couverture_url"]
    elif p.get("couverture_ms") is not None:
        params["thumb_offset"] = str(int(p["couverture_ms"]))
    st, _, d = requete_json("POST", f"{base}/{uid}/media", form=params)
    if st != 200 or not d.get("id"):
        raise ErreurPlateforme("Instagram a refusé la création : " + msg_erreur(d))
    conteneur = d["id"]
    uri = d.get("uri") or f"https://rupload.facebook.com/ig-api-upload/{IG_VERSION}/{conteneur}"

    def suivi(fraction):
        maj(tache, "instagram", progression=round(70 * fraction),
            message=f"Envoi de la vidéo… {round(100 * fraction)} %")

    with open(video, "rb") as f:
        st, _, b = requete("POST", uri, {
            "Authorization": "OAuth " + token,
            "offset": "0",
            "file_size": str(taille),
            "Content-Length": str(taille),
            "Content-Type": "application/octet-stream",
        }, LecteurProgression(f, taille, suivi), timeout=3600)
    if st != 200:
        try:
            err = json.loads(b.decode("utf-8"))
        except ValueError:
            err = {"_brut": b.decode("utf-8", "replace")}
        raise ErreurPlateforme("Envoi Instagram interrompu : " + msg_erreur(err))

    maj(tache, "instagram", progression=75, message="Instagram traite la vidéo…")
    limite = time.time() + 20 * 60
    while True:
        st, _, d = requete_json("GET", f"{base}/{conteneur}?" + urllib.parse.urlencode(
            {"fields": "status_code,status", "access_token": token}))
        code = d.get("status_code")
        if code == "FINISHED":
            break
        if code in ("ERROR", "EXPIRED"):
            raise ErreurPlateforme("Instagram n'a pas pu traiter la vidéo : " + str(d.get("status") or code))
        if time.time() > limite:
            raise ErreurPlateforme("Instagram met trop de temps à traiter la vidéo (20 min).")
        time.sleep(6)

    maj(tache, "instagram", progression=92, message="Publication du Reel…")
    st, _, d = requete_json("POST", f"{base}/{uid}/media_publish",
                            form={"creation_id": conteneur, "access_token": token})
    if st != 200 or not d.get("id"):
        raise ErreurPlateforme("Publication Instagram refusée : " + msg_erreur(d))
    _, _, m = requete_json("GET", f"{base}/{d['id']}?" + urllib.parse.urlencode(
        {"fields": "permalink", "access_token": token}))
    maj(tache, "instagram", etat="termine", progression=100, message="Reel publié sur Instagram",
        lien=m.get("permalink"))


def est_hdr(chemin: Path) -> bool:
    """Détecte une vidéo HDR (BT.2020 / HLG / PQ) en lisant l'en-tête MP4 ou MOV."""
    try:
        with open(chemin, "rb") as f:
            debut = f.read(8 << 20)
            f.seek(max(0, chemin.stat().st_size - (8 << 20)))
            fin = f.read()
    except OSError:
        return False
    for donnees in (debut, fin):
        i = donnees.find(b"colrnclx")
        while i >= 0:
            primaires, transfert = struct.unpack(">HH", donnees[i + 8:i + 12])
            if primaires == 9 or transfert in (16, 18):  # BT.2020, PQ, HLG
                return True
            i = donnees.find(b"colrnclx", i + 1)
    return False


def version_tiktok(chemin: Path, tache: dict) -> Path:
    """TikTok refuse souvent les vidéos HDR : on en fait une copie SDR H.264 (outil intégré à macOS)."""
    if not est_hdr(chemin) or not Path("/usr/bin/avconvert").exists():
        return chemin
    sortie = chemin.with_name(chemin.stem + "-sdr.mp4")
    if sortie.exists() and sortie.stat().st_size > 0:
        return sortie
    maj(tache, "tiktok", message="Conversion de la vidéo HDR en SDR pour TikTok… (une à deux minutes)")
    tmp = sortie.with_name(sortie.stem + "-en-cours.mp4")
    try:
        r = subprocess.run(["/usr/bin/avconvert", "-s", str(chemin), "-o", str(tmp),
                            "-p", "PresetHighestQuality", "--replace"],
                           capture_output=True, text=True, timeout=3600)
    except subprocess.TimeoutExpired:
        tmp.unlink(missing_ok=True)
        raise ErreurPlateforme("La conversion de la vidéo pour TikTok a pris trop de temps.")
    if r.returncode != 0 or not tmp.exists() or tmp.stat().st_size == 0:
        tmp.unlink(missing_ok=True)
        raise ErreurPlateforme("Impossible de convertir la vidéo HDR pour TikTok : " +
                               (r.stderr or r.stdout or "erreur inconnue").strip()[:200])
    tmp.replace(sortie)
    return sortie


def publier_tiktok(tache: dict, p: dict) -> None:
    tk = p["tiktok"]
    jeton = jeton_tiktok()
    video = version_tiktok(chemin_fichier(p["video"]), tache)
    taille = video.stat().st_size

    mo = 1024 * 1024
    if taille <= 64 * mo:
        bloc, nb = taille, 1
    else:
        bloc = 10 * mo
        nb = taille // bloc  # le dernier morceau absorbe le reste (≤ 20 Mo)

    visibilite = tk.get("visibilite") or "SELF_ONLY"
    if not app_tiktok()["audite"]:
        visibilite = "SELF_ONLY"
    post_info = {
        "title": (sans_mention_deepl(tk.get("legende")) or "")[:2200],
        "privacy_level": visibilite,
        "disable_comment": not tk.get("commentaires", True),
        "disable_duet": not tk.get("duo", True),
        "disable_stitch": not tk.get("stitch", True),
        "brand_content_toggle": bool(tk.get("contenu_marque")),
        "brand_organic_toggle": bool(tk.get("propre_marque")),
    }
    if p.get("couverture_ms") is not None:
        post_info["video_cover_timestamp_ms"] = int(p["couverture_ms"])

    # « brouillon » : la vidéo arrive dans la boîte de réception TikTok, à publier depuis l'app.
    brouillon = tk.get("mode") == "brouillon"
    source_info = {"source": "FILE_UPLOAD", "video_size": taille, "chunk_size": bloc, "total_chunk_count": nb}
    if brouillon:
        maj(tache, "tiktok", message="Préparation du brouillon TikTok…")
        st, _, d = requete_json("POST", "https://open.tiktokapis.com/v2/post/publish/inbox/video/init/",
                                {"Authorization": "Bearer " + jeton}, json_corps={"source_info": source_info})
    else:
        maj(tache, "tiktok", message="Préparation de la publication TikTok…")
        st, _, d = requete_json("POST", "https://open.tiktokapis.com/v2/post/publish/video/init/",
                                {"Authorization": "Bearer " + jeton},
                                json_corps={"post_info": post_info, "source_info": source_info})
    code_err = (d.get("error") or {}).get("code")
    if code_err != "ok":
        explications = {
            "unaudited_client_can_only_post_to_private_accounts":
                "Ton app TikTok n'est pas encore validée : TikTok n'accepte la publication que si ton compte est "
                "privé. Dans l'app TikTok : Profil → ☰ → Paramètres et confidentialité → Confidentialité → "
                "active « Compte privé », puis clique sur Réessayer.",
            "spam_risk_too_many_posts": "TikTok limite le nombre de publications par jour : réessaie demain.",
            "spam_risk_user_banned_from_posting": "Ce compte TikTok n'est temporairement pas autorisé à publier.",
            "reached_active_user_cap": "Limite quotidienne de l'app TikTok atteinte : réessaie demain.",
            "privacy_level_option_mismatch": "Le choix « Qui peut voir cette vidéo » n'est pas accepté par ton compte : choisis-en un autre.",
            "access_token_invalid": "Session TikTok expirée : reconnecte le compte dans l'onglet Comptes.",
            "scope_not_authorized": (
                "TikTok n'a pas encore autorisé l'envoi en brouillon : dans l'onglet Comptes, clique sur "
                "« Reconnecter » pour TikTok et laisse toutes les autorisations activées."
                if brouillon else
                "TikTok n'a pas donné l'autorisation de publier : reconnecte le compte en laissant « Publier du contenu » activé."),
        }
        raise ErreurPlateforme(explications.get(code_err) or "TikTok a refusé la publication : " + msg_erreur(d))
    publish_id = d["data"]["publish_id"]
    upload_url = d["data"]["upload_url"]
    print(f"  · TikTok — identifiant d'envoi : {publish_id}", flush=True)

    ct = type_mime(video)
    with open(video, "rb") as f:
        for i in range(nb):
            debut = i * bloc
            fin = taille - 1 if i == nb - 1 else debut + bloc - 1
            f.seek(debut)
            morceau = f.read(fin - debut + 1)
            for essai in range(5):
                try:
                    st, _, b = requete("PUT", upload_url, {
                        "Content-Type": ct,
                        "Content-Range": f"bytes {debut}-{fin}/{taille}",
                    }, morceau, timeout=600)
                    if st < 500:
                        break
                except (OSError, http.client.HTTPException):
                    st, b = 0, b""
                time.sleep(2 ** (essai + 1))
            if st not in (200, 201, 206):
                raise ErreurPlateforme(f"Envoi TikTok interrompu (code {st}) : " +
                                       b.decode("utf-8", "replace")[:200])
            frac = (fin + 1) / taille
            maj(tache, "tiktok", progression=round(80 * frac), message=f"Envoi de la vidéo… {round(100 * frac)} %")

    maj(tache, "tiktok", progression=85, message="TikTok traite la vidéo…")
    limite = time.time() + 15 * 60
    etat_precedent = None
    while True:
        st, _, d = requete_json("POST", "https://open.tiktokapis.com/v2/post/publish/status/fetch/",
                                {"Authorization": "Bearer " + jeton_tiktok()},
                                json_corps={"publish_id": publish_id})
        data = d.get("data") or {}
        if data.get("status") != etat_precedent:
            etat_precedent = data.get("status")
            print(f"  · TikTok — état : {etat_precedent}", flush=True)
        etat = data.get("status")
        if etat == "PUBLISH_COMPLETE" or (brouillon and etat == "SEND_TO_USER_INBOX"):
            break
        if etat == "FAILED":
            raise ErreurPlateforme("TikTok a rejeté la vidéo : " + str(data.get("fail_reason")))
        if time.time() > limite:
            ou = "ta boîte de réception TikTok" if brouillon else "ton profil"
            maj(tache, "tiktok", etat="avertissement", progression=100,
                message=f"Vidéo envoyée ; TikTok la traite encore (état : {etat or 'inconnu'}). "
                        f"Vérifie {ou} dans quelques minutes.")
            return
        time.sleep(5)
    if brouillon:
        maj(tache, "tiktok", etat="termine", progression=100, lien=None,
            message="Brouillon envoyé : ouvre l'app TikTok (notification ou boîte de réception), "
                    "colle la légende, puis publie.")
        return
    msg = "Publiée sur TikTok"
    if visibilite == "SELF_ONLY":
        msg += " (visible par toi seul — rends-la publique depuis l'app TikTok)"
    # L'API ne renvoie pas le pseudo (@) : pas de lien direct fiable vers la vidéo.
    maj(tache, "tiktok", etat="termine", progression=100, message=msg, lien=None)


PUBLIEURS = {"youtube": publier_youtube, "instagram": publier_instagram, "tiktok": publier_tiktok}


def lancer_publication(charge: dict) -> str:
    choisies = [p for p in charge.get("plateformes", []) if p in PUBLIEURS]
    if not choisies:
        raise ErreurPlateforme("Choisis au moins une plateforme.")
    chemin_fichier(charge.get("video"))
    ident = uuid.uuid4().hex[:12]
    tache = {
        "id": ident,
        "cree": datetime.now().isoformat(timespec="seconds"),
        "titre": charge.get("titre") or "",
        "plateformes": {p: {"etat": "en_attente", "progression": 0, "message": "En attente…", "lien": None}
                        for p in choisies},
    }
    TACHES[ident] = tache

    noms = {"youtube": "YouTube", "instagram": "Instagram", "tiktok": "TikTok"}

    def executer(p):
        maj(tache, p, etat="en_cours")
        try:
            PUBLIEURS[p](tache, charge)
        except ErreurPlateforme as e:
            maj(tache, p, etat="erreur", message=str(e))
        except Exception as e:  # noqa: BLE001 — on veut toujours un message lisible
            traceback.print_exc()
            maj(tache, p, etat="erreur", message=f"Erreur inattendue : {e}")
        s = tache["plateformes"][p]
        symbole = {"termine": "✅", "avertissement": "⚠️", "erreur": "❌"}.get(s["etat"], "•")
        print(f"  {symbole} {noms[p]} — {s['message']}" + (f"  {s['lien']}" if s.get("lien") else ""),
              flush=True)

    fils = [threading.Thread(target=executer, args=(p,), daemon=True) for p in choisies]
    for f in fils:
        f.start()

    def archiver():
        for f in fils:
            f.join()
        histo = lire(HISTO_F, [])
        histo.insert(0, {"date": tache["cree"], "titre": tache["titre"],
                         "plateformes": {p: {k: v[k] for k in ("etat", "message", "lien")}
                                         for p, v in tache["plateformes"].items()}})
        ecrire(HISTO_F, histo[:200])

    threading.Thread(target=archiver, daemon=True).start()
    return ident


# ---------------------------------------------------------------------------
# Serveur web local
# ---------------------------------------------------------------------------
def etat_comptes() -> dict:
    c, j = config(), jetons()
    return {
        "youtube": {"configure": bool(c.get("youtube_client_id") and c.get("youtube_client_secret")),
                    "connecte": "youtube" in j, "compte": j.get("youtube", {}).get("compte")},
        "instagram": {"configure": True, "connecte": "instagram" in j,
                      "compte": j.get("instagram", {}).get("compte")},
        "tiktok": {"configure": bool(app_tiktok()["cle"] and app_tiktok()["secret"]),
                   "app_fournie": app_tiktok()["fournie"],
                   "connecte": "tiktok" in j, "compte": j.get("tiktok", {}).get("compte"),
                   "audite": app_tiktok()["audite"],
                   "brouillon_autorise": "video.upload" in (j.get("tiktok", {}).get("scope") or "")},
        "config": {
            "youtube_client_id": c.get("youtube_client_id", ""),
            "youtube_secret_renseigne": bool(c.get("youtube_client_secret")),
            "tiktok_client_key": c.get("tiktok_client_key", ""),
            "tiktok_secret_renseigne": bool(c.get("tiktok_client_secret")),
            "tiktok_redirect_uri": c.get("tiktok_redirect_uri", ""),
            "tiktok_audite": bool(c.get("tiktok_audite")),
            "meta_app_id": c.get("meta_app_id", ""),
            "meta_secret_renseigne": bool(c.get("meta_app_secret")),
            "deepl_renseigne": bool(c.get("deepl_api_key")),
        },
        "langues": {code: nom for code, (_, nom) in LANGUES.items()},
        "redirections": {"youtube": redirect_uri("youtube"),
                         "tiktok_local": f"http://localhost:{PORT}/oauth/tiktok",
                         "tiktok": redirect_uri("tiktok")},
    }


class Gestionnaire(http.server.BaseHTTPRequestHandler):
    server_version = "Planificateur/1.1"

    def log_message(self, fmt, *args):
        if "/api/taches/" not in str(args[0] if args else ""):
            sys.stderr.write("  " + (fmt % args) + "\n")

    # --- utilitaires
    def _hote_ok(self) -> bool:
        hote = (self.headers.get("Host") or "").lower()
        if hote not in (f"localhost:{PORT}", f"127.0.0.1:{PORT}"):
            self.send_error(403)
            return False
        origine = self.headers.get("Origin")
        if self.command == "POST" and origine and origine not in (
                f"http://localhost:{PORT}", f"http://127.0.0.1:{PORT}"):
            self.send_error(403)
            return False
        return True

    def _json(self, obj, statut=200):
        corps = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(statut)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(corps)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(corps)

    def _redir(self, url):
        self.send_response(302)
        self.send_header("Location", url)
        self.end_headers()

    def _corps_json(self) -> dict:
        n = int(self.headers.get("Content-Length") or 0)
        try:
            return json.loads(self.rfile.read(n).decode("utf-8") or "{}") if n else {}
        except ValueError:
            return {}

    def _statique(self, nom):
        chemin = (INTERFACE / nom).resolve()
        if INTERFACE.resolve() not in chemin.parents or not chemin.is_file():
            self.send_error(404)
            return
        corps = chemin.read_bytes()
        self.send_response(200)
        ct = mimetypes.guess_type(str(chemin))[0] or "application/octet-stream"
        if ct.startswith("text/") or ct.endswith("javascript"):
            ct += "; charset=utf-8"
        self.send_header("Content-Type", ct)
        self.send_header("Content-Length", str(len(corps)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(corps)

    # --- GET
    def do_GET(self):
        if not self._hote_ok():
            return
        u = urllib.parse.urlsplit(self.path)
        q = dict(urllib.parse.parse_qsl(u.query))
        try:
            if u.path in ("/", "/index.html"):
                return self._statique("index.html")
            if u.path in ("/style.css", "/app.js"):
                return self._statique(u.path[1:])
            if u.path == "/favicon.ico":
                self.send_response(204)
                self.end_headers()
                return
            if u.path == "/api/comptes":
                return self._json(etat_comptes())
            if u.path == "/api/historique":
                return self._json(lire(HISTO_F, []))
            if u.path.startswith("/api/taches/"):
                t = TACHES.get(u.path.rsplit("/", 1)[-1])
                return self._json(t) if t else self._json({"erreur": "Tâche inconnue"}, 404)
            if u.path == "/api/tiktok/createur":
                return self._json(infos_createur_tiktok())
            if u.path == "/oauth/youtube/demarrer":
                return self._redir(url_auth_youtube())
            if u.path == "/oauth/tiktok/demarrer":
                return self._redir(url_auth_tiktok())
            if u.path in ("/oauth/youtube", "/oauth/tiktok", "/oauth/tiktok/"):
                p = u.path.rstrip("/").rsplit("/", 1)[-1]
                if q.get("error"):
                    raise ErreurPlateforme(q.get("error_description") or q["error"])
                extra = verifier_etat(q.get("state"), p)
                if p == "youtube":
                    echanger_code_youtube(q.get("code", ""))
                else:
                    echanger_code_tiktok(q.get("code", ""), extra)
                return self._redir(f"/?connecte={p}")
            self.send_error(404)
        except ErreurPlateforme as e:
            if u.path.startswith("/oauth/"):
                return self._redir("/?erreur=" + urllib.parse.quote(str(e)))
            self._json({"erreur": str(e)}, 400)
        except Exception as e:  # noqa: BLE001
            traceback.print_exc()
            self._json({"erreur": f"Erreur inattendue : {e}"}, 500)

    # --- POST
    def do_POST(self):
        if not self._hote_ok():
            return
        u = urllib.parse.urlsplit(self.path)
        q = dict(urllib.parse.parse_qsl(u.query))
        try:
            if u.path == "/api/fichier":
                return self._recevoir_fichier(q.get("nom", ""))
            corps = self._corps_json()
            if u.path == "/api/config":
                c = config()
                for cle in ("youtube_client_id", "youtube_client_secret", "tiktok_client_key",
                            "tiktok_client_secret", "tiktok_redirect_uri", "meta_app_id", "meta_app_secret",
                            "deepl_api_key"):
                    if cle in corps and (corps[cle] or not cle.endswith(("secret", "_key"))):
                        c[cle] = str(corps[cle]).strip()
                if "tiktok_audite" in corps:
                    c["tiktok_audite"] = bool(corps["tiktok_audite"])
                ecrire(CONFIG_F, c)
                return self._json(etat_comptes())
            if u.path == "/api/instagram/jeton":
                connecter_instagram(corps.get("jeton", ""))
                return self._json(etat_comptes())
            if u.path == "/api/tiktok/code":
                texte = (corps.get("url") or "").strip()
                params = dict(urllib.parse.parse_qsl(urllib.parse.urlsplit(texte).query)) if "?" in texte else {}
                code = params.get("code") or texte
                extra = verifier_etat(params["state"], "tiktok") if params.get("state") else None
                echanger_code_tiktok(code, extra)
                return self._json(etat_comptes())
            if u.path.startswith("/api/deconnecter/"):
                p = u.path.rsplit("/", 1)[-1]
                if p in PLATEFORMES:
                    maj_jetons(p, None)
                return self._json(etat_comptes())
            if u.path == "/api/publier":
                return self._json({"id": lancer_publication(corps)})
            if u.path == "/api/traduire":
                return self._json(traduire(corps.get("titre") or "", corps.get("description") or "",
                                           corps.get("langues") or []))
            self.send_error(404)
        except ErreurPlateforme as e:
            self._json({"erreur": str(e)}, 400)
        except Exception as e:  # noqa: BLE001
            traceback.print_exc()
            self._json({"erreur": f"Erreur inattendue : {e}"}, 500)

    def _recevoir_fichier(self, nom: str):
        ext = Path(nom).suffix.lower()
        if ext not in EXT_VIDEO | EXT_IMAGE:
            raise ErreurPlateforme("Format non pris en charge (vidéo : MP4/MOV/WEBM, image : JPG/PNG).")
        restant = int(self.headers.get("Content-Length") or 0)
        if restant <= 0:
            raise ErreurPlateforme("Fichier vide.")
        FICHIERS.mkdir(parents=True, exist_ok=True)
        ident = uuid.uuid4().hex + ext
        with open(FICHIERS / ident, "wb") as f:
            while restant > 0:
                bloc = self.rfile.read(min(restant, 4 * 1024 * 1024))
                if not bloc:
                    break
                f.write(bloc)
                restant -= len(bloc)
        if restant:
            (FICHIERS / ident).unlink(missing_ok=True)
            raise ErreurPlateforme("Import interrompu.")
        self._json({"id": ident})


def nettoyer_vieux_fichiers():
    if not FICHIERS.is_dir():
        return
    limite = time.time() - CONSERVATION_FICHIERS_JOURS * 86400
    for f in FICHIERS.iterdir():
        if f.is_file() and f.stat().st_mtime < limite:
            f.unlink(missing_ok=True)


def ouvrir_navigateur(url: str) -> None:
    """Ouvre la page dans le navigateur par défaut (commande « open » sur macOS)."""
    try:
        if sys.platform == "darwin":
            subprocess.run(["open", url], check=True, timeout=10)
            return
    except (OSError, subprocess.SubprocessError):
        pass
    webbrowser.open(url)


def outil_deja_lance() -> bool:
    try:
        st, _, d = requete_json("GET", f"http://127.0.0.1:{PORT}/api/comptes", timeout=2)
        return st == 200 and "youtube" in d
    except (OSError, http.client.HTTPException):
        return False


def main():
    url = f"http://localhost:{PORT}"
    sans_nav = "--sans-navigateur" in sys.argv

    # L'outil tourne déjà (autre fenêtre Terminal) : on rouvre simplement la page.
    if outil_deja_lance():
        print(f"\n  Le Planificateur est déjà lancé : ouverture de {url}\n")
        if not sans_nav:
            ouvrir_navigateur(url)
        return

    DONNEES.mkdir(parents=True, exist_ok=True)
    os.chmod(DONNEES, 0o700)
    nettoyer_vieux_fichiers()
    try:
        serveur = http.server.ThreadingHTTPServer((HOTE, PORT), Gestionnaire)
    except OSError:
        print(f"\n  Impossible de démarrer : le port {PORT} est déjà utilisé par une autre application.")
        print("  Ferme cette application (ou redémarre le Mac), puis relance le Planificateur.\n")
        sys.exit(1)

    print(f"\n  Le Planificateur est prêt : {url}")
    print("  Laisse cette fenêtre ouverte pendant les publications. Ctrl+C pour arrêter.\n")
    if not sans_nav:
        threading.Timer(0.5, ouvrir_navigateur, args=(url,)).start()
    try:
        serveur.serve_forever()
    except KeyboardInterrupt:
        print("\n  Arrêt.")


if __name__ == "__main__":
    main()
