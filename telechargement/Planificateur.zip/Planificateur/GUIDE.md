# Planificateur — guide d'installation

Tu importes une vidéo une seule fois. Tu écris le titre, la description et les hashtags, puis tu choisis une image d'aperçu. L'outil publie ensuite sur **YouTube**, **Instagram (Reel)** et **TikTok** en un clic.

L'outil tourne sur ton Mac, avec le Python déjà présent sur macOS : il n'y a rien à installer. Tes identifiants restent dans le dossier `donnees/`, sur ton ordinateur.

---

## 1. Démarrer l'outil

Double-clique sur **`Lancer.command`**.

- **Si macOS bloque le fichier** (« impossible de vérifier le développeur ») :
  1. Fais un **clic droit** sur le fichier, puis choisis **Ouvrir** et confirme.
  2. Si ça ne suffit pas, ouvre **Réglages Système → Confidentialité et sécurité**, descends jusqu'en bas et clique sur **Ouvrir quand même**.
- **Ce qui se passe ensuite :** une fenêtre Terminal s'ouvre, puis ton navigateur affiche `http://localhost:8765`.
- **Pendant l'utilisation :** laisse la fenêtre Terminal ouverte. Pour arrêter l'outil, ferme-la.
- **Si la page s'est fermée** alors que l'outil tourne encore : relance `Lancer.command` pour la rouvrir, ou tape `localhost:8765` dans ton navigateur.

Tu peux aussi lancer l'outil depuis le Terminal :

```bash
cd ~/Desktop/Planificateur && python3 serveur.py
```

---

## 2. Connecter les comptes (une seule fois)

Pour chaque plateforme, tu crées une « application développeur » gratuite. Elle autorise **ton** outil à publier sur **tes** comptes. Compte environ 15 minutes par plateforme.

### YouTube (Google Cloud)

1. Va sur <https://console.cloud.google.com/> et crée un projet.
2. Ouvre **API et services → Bibliothèque**, puis active **YouTube Data API v3**.
3. Ouvre **Écran de consentement OAuth** :
   - type d'utilisateur : **Externe** ;
   - ajoute l'adresse Google de ta chaîne dans **Utilisateurs test**.
4. Ouvre **Identifiants → Créer des identifiants → ID client OAuth** :
   - type : **Application Web** ;
   - URI de redirection autorisé : `http://localhost:8765/oauth/youtube`.
5. Colle l'**ID client** et le **Code secret** dans l'onglet **Comptes**, puis clique sur **Enregistrer** et sur **Connecter ma chaîne**.

Google affiche « application non validée » ? Clique sur **Paramètres avancés → Accéder à…**.

**À savoir :**
- **Vidéos privées au début.** Tant que Google n'a pas audité ton projet, les vidéos restent privées. La demande d'audit se fait ici : <https://support.google.com/youtube/contact/yt_api_form>. En attendant, rends-les publiques dans YouTube Studio.
- **Miniature personnalisée.** Ta chaîne doit être validée par téléphone (<https://www.youtube.com/verify>) et l'image doit faire 2 Mo maximum.
- **Reconnexion chaque semaine.** Tant que l'appli Google est en mode « Test », la connexion expire après 7 jours : clique sur **Reconnecter**. Passe l'appli en « Production » pour éviter ça.

### Instagram (Meta)

Il te faut un compte Instagram **professionnel** (Créateur ou Entreprise).

1. Va sur <https://developers.facebook.com/apps> et choisis **Créer une app**, avec le cas d'usage « Gérer les messages et le contenu sur Instagram ».
2. Ouvre **Instagram → Configuration de l'API avec connexion Instagram**.
3. Dans **Générer des tokens d'accès**, clique sur **Ajouter un compte**, connecte ton compte, puis clique sur **Générer un token**.
4. Colle le jeton dans l'onglet **Comptes**, puis clique sur **Connecter Instagram**.

**À savoir :**
- **Renouvellement du jeton.** L'outil le renouvelle tout seul, à condition que tu publies au moins une fois tous les 60 jours.
- **Image de couverture.** Instagram n'accepte une image personnalisée que si elle est en ligne. Sinon, l'outil utilise le moment de la vidéo que tu as choisi.

### TikTok

1. Va sur <https://developers.tiktok.com/>, puis **Manage apps → Connect an app**.
2. Ajoute **Login Kit** et **Content Posting API**, et active **Direct Post**.
3. Ajoute les autorisations **user.info.basic** et **video.publish**.
4. **Adresse de retour :** TikTok exige une adresse en `https://`.
   1. Mets le fichier **`tiktok-callback.html`** en ligne sur ton site, par exemple `https://tonsite.fr/tiktok-callback.html`.
   2. Déclare cette adresse comme **Redirect URI** chez TikTok.
5. Ajoute ton compte TikTok dans **Sandbox → Target users**.
6. Dans l'onglet **Comptes**, colle la **Client key**, le **Client secret** et la Redirect URI. Clique sur **Enregistrer**, puis sur **Connecter TikTok**.

**À savoir :**
- **Vidéos privées au début.** Avant l'audit de TikTok, les vidéos sont publiées en « Moi uniquement ». Tu peux les rendre publiques depuis l'app TikTok.
- **Pas d'image de couverture.** TikTok utilise le moment de la vidéo que tu as choisi.

### Traduction YouTube (DeepL)

Facultatif : sert à traduire automatiquement le titre et la description YouTube dans d'autres langues.

1. Crée un compte sur <https://www.deepl.com/fr/pro-api>, forfait gratuit **Developer** (« Créer un compte gratuitement »). N'utilise pas « Essayer gratuitement » : c'est un essai payant après 30 jours.
2. Dans ton compte DeepL, onglet **Clés API**, copie ta clé.
3. Dans le Planificateur, onglet **Comptes**, carte **Traduction (DeepL)** : colle la clé, puis clique sur **Enregistrer**.

Le forfait gratuit donne un crédit unique d'un million de caractères, soit environ 200 vidéos traduites en 5 langues.

---

## 3. Publier une vidéo

1. **Vidéo :** glisse ton fichier MP4, MOV ou WEBM.
2. **Image d'aperçu :** place la vidéo sur la bonne image et clique sur **Utiliser l'image affichée**. Tu peux aussi importer une miniature.
3. **Textes :** écris le titre, la description et les hashtags. Ils remplissent automatiquement les champs de chaque plateforme.
4. **Plateformes :** ajuste chaque texte si besoin et désactive les plateformes que tu ne veux pas.
   - **Traductions YouTube :** dans la carte YouTube, coche **Ajouter des traductions**, choisis les langues, puis clique sur **Traduire**. Relis ou corrige chaque langue si besoin. Chaque spectateur voit automatiquement le titre et la description dans sa langue. Si tu modifies le texte français ensuite, clique de nouveau sur **Traduire**.
5. Clique sur **Publier**. Tu suis l'avancement de chaque plateforme et tu obtiens un lien vers chaque publication.

---

## 4. En cas de problème

| Problème | Solution |
|---|---|
| Rien ne s'ouvre au double-clic | Clic droit sur `Lancer.command`, puis **Ouvrir**. Voir aussi la partie 1. |
| « le port 8765 est déjà utilisé » | Une autre application occupe le port : redémarre le Mac. |
| La fenêtre Terminal s'ouvre, mais pas la page | Tape `localhost:8765` dans ton navigateur. |
| « Session expirée » | Onglet **Comptes**, puis **Reconnecter**. |
| `redirect_uri_mismatch` (Google) | L'URI doit être exactement `http://localhost:8765/oauth/youtube`. |

Les dossiers `donnees/` (identifiants) et `donnees/fichiers/` (vidéos importées, supprimées au bout de 14 jours) donnent accès à tes comptes : **ne les partage pas**.
