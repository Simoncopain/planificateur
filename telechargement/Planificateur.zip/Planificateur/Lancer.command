#!/bin/bash
# Double-clique sur ce fichier pour démarrer le Planificateur.
cd "$(dirname "$0")" || exit 1

PY="$(command -v python3 || echo /usr/bin/python3)"
if ! "$PY" -c "import sys" >/dev/null 2>&1; then
  echo ""
  echo "  Python 3 est introuvable. macOS va proposer d'installer les outils de développement :"
  echo "  accepte, puis relance ce fichier."
  xcode-select --install 2>/dev/null
  read -n 1 -s -r -p "  Appuie sur une touche pour fermer…"
  exit 1
fi

"$PY" serveur.py
code=$?
if [ $code -ne 0 ]; then
  echo ""
  read -n 1 -s -r -p "  Une erreur s'est produite (voir ci-dessus). Appuie sur une touche pour fermer…"
fi
