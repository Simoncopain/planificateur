"use strict";

const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const NOMS = { youtube: "YouTube", instagram: "Instagram", tiktok: "TikTok" };
const PUCES = { youtube: "yt", instagram: "ig", tiktok: "tk" };

const etat = {
  video: null,          // identifiant du fichier côté serveur
  importEnCours: false,
  miniature: null,      // identifiant de l'image
  couvertureMs: null,
  comptes: null,
  createurTikTok: null,
  tache: null,
};

// ---------------------------------------------------------------- utilitaires
function toast(msg, erreur = false) {
  const t = $("#toast");
  t.textContent = msg;
  t.className = "toast" + (erreur ? " erreur" : "");
  t.hidden = false;
  clearTimeout(toast._t);
  toast._t = setTimeout(() => (t.hidden = true), erreur ? 7000 : 3500);
}

async function api(chemin, options = {}) {
  const init = { ...options };
  if (options.json !== undefined) {
    init.method = init.method || "POST";
    init.headers = { "Content-Type": "application/json" };
    init.body = JSON.stringify(options.json);
  }
  const r = await fetch(chemin, init);
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.erreur || `Erreur ${r.status}`);
  return d;
}

const memo = {
  lire(cle, defaut) { try { return JSON.parse(localStorage.getItem(cle)) ?? defaut; } catch { return defaut; } },
  ecrire(cle, val) { try { localStorage.setItem(cle, JSON.stringify(val)); } catch { /* stockage indisponible */ } },
};

function echapper(s) {
  return String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function formatTaille(o) {
  if (o > 1e9) return (o / 1e9).toFixed(2) + " Go";
  return (o / 1e6).toFixed(1) + " Mo";
}
function formatDuree(s) {
  const m = Math.floor(s / 60), r = s - m * 60;
  return `${m}:${r.toFixed(1).padStart(4, "0")}`;
}

// ---------------------------------------------------------------- onglets
function afficherVue(nom) {
  $$(".onglet").forEach((b) => b.classList.toggle("actif", b.dataset.vue === nom));
  $$(".vue").forEach((v) => (v.hidden = v.id !== "vue-" + nom));
  $(".barre-publier").hidden = nom !== "publier";
  if (nom === "historique") chargerHistorique();
}
$$(".onglet").forEach((b) => b.addEventListener("click", () => afficherVue(b.dataset.vue)));

// ---------------------------------------------------------------- import de fichiers
function envoyerFichier(fichier, progression) {
  return new Promise((ok, ko) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/api/fichier?nom=" + encodeURIComponent(fichier.name));
    xhr.upload.onprogress = (e) => e.lengthComputable && progression && progression(e.loaded / e.total);
    xhr.onload = () => {
      let d = {};
      try { d = JSON.parse(xhr.responseText); } catch { /* réponse vide */ }
      xhr.status === 200 ? ok(d.id) : ko(new Error(d.erreur || "Import impossible"));
    };
    xhr.onerror = () => ko(new Error("Le serveur local ne répond pas. Est-il toujours lancé ?"));
    xhr.send(fichier);
  });
}

const apercu = $("#apercu");

async function choisirVideo(fichier) {
  if (!fichier) return;
  if (!/\.(mp4|mov|m4v|webm)$/i.test(fichier.name)) return toast("Choisis une vidéo MP4, MOV ou WEBM.", true);
  etat.video = null;
  etat.couvertureMs = null;
  $("#depot").hidden = true;
  $("#bloc-video").hidden = false;
  $("#info-nom").textContent = fichier.name;
  $("#info-details").textContent = formatTaille(fichier.size);
  $("#alertes-video").innerHTML = "";
  apercu.src = URL.createObjectURL(fichier);
  $("#capturer").disabled = false;
  majMoment();

  const barre = $("#barre-import");
  barre.className = "barre-remplie";
  etat.importEnCours = true;
  majResume();
  try {
    etat.video = await envoyerFichier(fichier, (f) => {
      barre.style.width = Math.round(f * 100) + "%";
      $("#etat-import").textContent = `Préparation… ${Math.round(f * 100)} %`;
    });
    barre.style.width = "100%";
    barre.classList.add("ok");
    $("#etat-import").textContent = "Vidéo prête à être publiée";
  } catch (e) {
    barre.classList.add("ko");
    $("#etat-import").textContent = e.message;
  } finally {
    etat.importEnCours = false;
    majResume();
  }
}

apercu.addEventListener("loadedmetadata", () => {
  const w = apercu.videoWidth, h = apercu.videoHeight, d = apercu.duration;
  etat.dureeVideo = d;
  $("#info-details").textContent += ` · ${w}×${h} · ${formatDuree(d)}`;
  const alertes = [];
  if (w > h * 1.05) alertes.push("Vidéo horizontale : sur Instagram et TikTok elle s'affichera avec des bandes. Le format 9:16 est conseillé.");
  if (d > 15 * 60) alertes.push("Plus de 15 minutes : Instagram refusera la vidéo, et YouTube exige une chaîne validée.");
  else if (d > 10 * 60) alertes.push("Plus de 10 minutes : vérifie que ton compte TikTok autorise cette durée.");
  if (d < 3) alertes.push("Moins de 3 secondes : Instagram et TikTok risquent de refuser la vidéo.");
  $("#alertes-video").innerHTML = alertes.map((a) => `<p class="note">${echapper(a)}</p>`).join("");
});

const depot = $("#depot");
["dragenter", "dragover"].forEach((ev) => depot.addEventListener(ev, (e) => { e.preventDefault(); depot.classList.add("survol"); }));
["dragleave", "drop"].forEach((ev) => depot.addEventListener(ev, (e) => { e.preventDefault(); depot.classList.remove("survol"); }));
depot.addEventListener("drop", (e) => choisirVideo(e.dataTransfer.files[0]));
$("#champ-video").addEventListener("change", (e) => choisirVideo(e.target.files[0]));
$("#changer-video").addEventListener("click", () => $("#champ-video").click());

// ---------------------------------------------------------------- couverture
function majMoment() {
  $("#info-moment").textContent = etat.couvertureMs == null
    ? "Moment de couverture TikTok / Instagram : début de la vidéo"
    : `Moment de couverture TikTok / Instagram : ${formatDuree(etat.couvertureMs / 1000)}`;
}

async function definirMiniature(blobOuFichier, nom) {
  const url = URL.createObjectURL(blobOuFichier);
  const v = $("#vignette");
  v.classList.remove("vide");
  v.textContent = "";
  v.style.backgroundImage = `url("${url}")`;
  $("#retirer-miniature").hidden = false;
  etat.miniature = null;
  try {
    const f = blobOuFichier instanceof File ? blobOuFichier : new File([blobOuFichier], nom, { type: "image/jpeg" });
    etat.miniature = await envoyerFichier(f);
  } catch (e) {
    toast(e.message, true);
  }
}

$("#capturer").addEventListener("click", async () => {
  if (!apercu.videoWidth) return toast("La vidéo n'est pas encore chargée.", true);
  apercu.pause();
  etat.couvertureMs = Math.round(apercu.currentTime * 1000);
  majMoment();
  // Image max 1920 px, sous 2 Mo (limite YouTube)
  const echelle = Math.min(1, 1920 / Math.max(apercu.videoWidth, apercu.videoHeight));
  const c = document.createElement("canvas");
  c.width = Math.round(apercu.videoWidth * echelle);
  c.height = Math.round(apercu.videoHeight * echelle);
  c.getContext("2d").drawImage(apercu, 0, 0, c.width, c.height);
  let qualite = 0.92, blob;
  do {
    blob = await new Promise((r) => c.toBlob(r, "image/jpeg", qualite));
    qualite -= 0.1;
  } while (blob.size > 1.9e6 && qualite > 0.4);
  definirMiniature(blob, "couverture.jpg");
});

$("#champ-miniature").addEventListener("change", (e) => {
  const f = e.target.files[0];
  if (!f) return;
  if (f.size > 2 * 1024 * 1024) toast("Image de plus de 2 Mo : YouTube la refusera. Compresse-la avant.", true);
  definirMiniature(f, f.name);
  e.target.value = "";
});

$("#retirer-miniature").addEventListener("click", () => {
  etat.miniature = null;
  const v = $("#vignette");
  v.style.backgroundImage = "";
  v.classList.add("vide");
  v.textContent = "Aucune image";
  $("#retirer-miniature").hidden = true;
});

// ---------------------------------------------------------------- textes
function hashtags() {
  return $("#hashtags").value.split(/[\s,]+/).map((h) => h.replace(/^#+/, "").trim()).filter(Boolean);
}

function textesCalcules() {
  const titre = $("#titre").value.trim();
  const desc = $("#description").value.trim();
  const tags = hashtags().map((h) => "#" + h).join(" ");
  const corps = [desc, tags].filter(Boolean).join("\n\n");
  const legende = $("#titre-dans-legende").checked
    ? [titre, corps].filter(Boolean).join("\n\n")
    : corps || titre;
  return {
    "yt-titre": titre,
    "yt-description": corps,
    "ig-legende": legende,
    "tk-legende": legende,
  };
}

// Les champs par plateforme suivent les textes communs tant que tu ne les modifies pas.
const modifies = new Set();
function synchroniser() {
  const t = textesCalcules();
  $$("[data-auto]").forEach((el) => {
    if (!modifies.has(el.id)) el.value = t[el.id];
  });
  majCompteurs();
  memo.ecrire("brouillon", {
    titre: $("#titre").value, description: $("#description").value, hashtags: $("#hashtags").value,
  });
}

$$("[data-auto]").forEach((el) => {
  const libelle = el.closest(".champ").querySelector("span");
  const bouton = document.createElement("button");
  bouton.type = "button";
  bouton.className = "reinit";
  bouton.textContent = "Revenir au texte commun";
  bouton.hidden = true;
  libelle.appendChild(bouton);
  el.addEventListener("input", () => { modifies.add(el.id); bouton.hidden = false; majCompteurs(); });
  bouton.addEventListener("click", () => { modifies.delete(el.id); bouton.hidden = true; synchroniser(); });
});

["#titre", "#description", "#hashtags", "#titre-dans-legende"].forEach((s) => $(s).addEventListener("input", synchroniser));

function majCompteurs() {
  $$(".compteur").forEach((c) => {
    const n = $("#" + c.dataset.pour).value.length, max = +c.dataset.max;
    c.textContent = `${n} / ${max}`;
    c.classList.toggle("trop", n > max);
  });
}

// ---------------------------------------------------------------- plateformes
function plateformesActives() {
  return $$(".plateforme").filter((a) => $(".activer", a).checked).map((a) => a.dataset.p);
}

$$(".plateforme .activer").forEach((c) => c.addEventListener("change", () => {
  c.closest(".plateforme").classList.toggle("inactive", !c.checked);
  memo.ecrire("actives", plateformesActives());
  majResume();
}));

function majResume() {
  const actives = plateformesActives();
  const nonConnectees = actives.filter((p) => !etat.comptes?.[p]?.connecte);
  const b = $("#publier");
  let msg = "";
  if (!etat.video && !etat.importEnCours) msg = "Importe une vidéo pour commencer.";
  else if (etat.importEnCours) msg = "Préparation de la vidéo…";
  else if (!actives.length) msg = "Active au moins une plateforme.";
  else if (nonConnectees.length) msg = `À connecter dans « Comptes » : ${nonConnectees.map((p) => NOMS[p]).join(", ")}.`;
  else if (actives.includes("tiktok") && typeof commercialIncomplet === "function" && modeTikTok() !== "brouillon" && commercialIncomplet())
    msg = "Contenu commercial TikTok : coche au moins une option.";
  $("#resume-publier").textContent = msg;
  b.disabled = !!msg || etat.tache !== null;
  b.textContent = actives.length > 1 ? `Publier sur ${actives.length} plateformes` : actives.length ? `Publier sur ${NOMS[actives[0]]}` : "Publier";
}

// Options mémorisées d'une vidéo à l'autre
const OPTIONS = ["yt-visibilite", "yt-categorie", "yt-enfants", "ig-fil"]; // TikTok : Commentaires, Duo et Collage jamais cochés par défaut (règle TikTok)
function restaurerOptions() {
  const o = memo.lire("options", {});
  OPTIONS.forEach((id) => {
    if (!(id in o)) return;
    const el = $("#" + id);
    el.type === "checkbox" ? (el.checked = o[id]) : (el.value = o[id]);
  });
  const actives = memo.lire("actives", null);
  if (actives) $$(".plateforme").forEach((a) => {
    const on = actives.includes(a.dataset.p);
    $(".activer", a).checked = on;
    a.classList.toggle("inactive", !on);
  });
  const b = memo.lire("brouillon", null);
  if (b) { $("#titre").value = b.titre || ""; $("#description").value = b.description || ""; $("#hashtags").value = b.hashtags || ""; }
}
function sauverOptions() {
  const o = {};
  OPTIONS.forEach((id) => { const el = $("#" + id); o[id] = el.type === "checkbox" ? el.checked : el.value; });
  memo.ecrire("options", o);
}
OPTIONS.forEach((id) => $("#" + id).addEventListener("change", sauverOptions));

// ---------------------------------------------------------------- traductions YouTube
const trad = { resultats: {}, source: null };
const sourceFr = () => $("#yt-titre").value.trim() + "\n" + $("#yt-description").value;
const languesChoisies = () => $$("#tr-langues input:checked").map((c) => c.value);

function construireLangues(langues) {
  const conteneur = $("#tr-langues");
  if (conteneur.childElementCount) return;
  const choisies = memo.lire("langues", ["en", "es"]);
  conteneur.innerHTML = Object.entries(langues).map(([code, nom]) =>
    `<label class="langue"><input type="checkbox" value="${code}" ${choisies.includes(code) ? "checked" : ""}><span>${echapper(nom)}</span></label>`).join("");
  $$("input", conteneur).forEach((c) => c.addEventListener("change", () => { memo.ecrire("langues", languesChoisies()); afficherTraductions(); }));
}

function afficherTraductions() {
  const noms = etat.comptes?.langues || {};
  const codes = languesChoisies().filter((c) => trad.resultats[c]);
  $("#tr-resultats").innerHTML = codes.map((c) => `
    <details class="trad" data-code="${c}">
      <summary>${echapper(noms[c] || c)}</summary>
      <label class="champ"><span>Titre</span><input class="tr-titre" maxlength="100" value="${echapper(trad.resultats[c].titre)}"></label>
      <label class="champ"><span>Description</span><textarea class="tr-desc" rows="4" maxlength="5000">${echapper(trad.resultats[c].description)}</textarea></label>
    </details>`).join("");
  // Les corrections manuelles sont conservées.
  $$(".trad").forEach((d) => {
    const c = d.dataset.code;
    $(".tr-titre", d).addEventListener("input", (e) => (trad.resultats[c].titre = e.target.value));
    $(".tr-desc", d).addEventListener("input", (e) => (trad.resultats[c].description = e.target.value));
  });
  majEtatTraduction();
}

function majEtatTraduction() {
  const choisies = languesChoisies();
  const manquantes = choisies.filter((c) => !trad.resultats[c]);
  let txt = "";
  if (!choisies.length) txt = "Choisis au moins une langue.";
  else if (trad.source !== null && trad.source !== sourceFr()) txt = "Le texte français a changé : clique sur Traduire pour mettre à jour.";
  else if (manquantes.length) txt = `${manquantes.length} langue${manquantes.length > 1 ? "s" : ""} à traduire.`;
  else txt = "Traductions prêtes. Clique sur une langue pour relire ou corriger.";
  $("#tr-etat").textContent = txt;
}

$("#yt-traduire").addEventListener("change", (e) => {
  $("#bloc-traductions").hidden = !e.target.checked;
  memo.ecrire("traduire", e.target.checked);
  majEtatTraduction();
});
["#yt-titre", "#yt-description"].forEach((s) => $(s).addEventListener("input", majEtatTraduction));
["#titre", "#description", "#hashtags"].forEach((s) => $(s).addEventListener("input", majEtatTraduction));

$("#tr-lancer").addEventListener("click", async () => {
  const langues = languesChoisies();
  if (!langues.length) return toast("Choisis au moins une langue.", true);
  if (!$("#yt-titre").value.trim()) return toast("Écris d'abord le titre en français.", true);
  const b = $("#tr-lancer");
  b.disabled = true;
  b.textContent = "Traduction…";
  try {
    const source = sourceFr();
    const r = await api("/api/traduire", { json: { titre: $("#yt-titre").value.trim(), description: $("#yt-description").value, langues } });
    trad.resultats = { ...trad.resultats, ...r };
    // Les langues déjà traduites depuis un ancien texte sont remplacées.
    Object.keys(trad.resultats).forEach((c) => { if (!(c in r)) delete trad.resultats[c]; });
    trad.source = source;
    afficherTraductions();
    toast(`Traduit en ${langues.length} langue${langues.length > 1 ? "s" : ""}`);
  } catch (e) {
    toast(e.message, true);
  } finally {
    b.disabled = false;
    b.textContent = "Traduire";
  }
});

function traductionsPourPublication() {
  if (!$("#yt-traduire").checked) return { traductions: null };
  const choisies = languesChoisies();
  if (!choisies.length) return { erreur: "Choisis au moins une langue de traduction YouTube, ou décoche « Ajouter des traductions »." };
  if (choisies.some((c) => !trad.resultats[c]) || trad.source !== sourceFr())
    return { erreur: "Clique sur « Traduire » dans la carte YouTube avant de publier." };
  return { traductions: Object.fromEntries(choisies.map((c) => [c, trad.resultats[c]])) };
}

// ---------------------------------------------------------------- TikTok : infos créateur
const LIBELLES_TK = {
  PUBLIC_TO_EVERYONE: "Tout le monde",
  MUTUAL_FOLLOW_FRIENDS: "Amis (abonnements mutuels)",
  FOLLOWER_OF_CREATOR: "Mes abonnés",
  SELF_ONLY: "Moi uniquement",
};
async function chargerCreateurTikTok() {
  const sel = $("#tk-visibilite");
  const audite = etat.comptes?.tiktok?.audite;
  $("#tk-note-audit").hidden = !!audite || !etat.comptes?.tiktok?.connecte;
  let options = ["SELF_ONLY"];
  if (etat.comptes?.tiktok?.connecte) {
    try {
      const d = await api("/api/tiktok/createur");
      etat.createurTikTok = d;
      etat.erreurCreateurTikTok = null;
      const pseudo = [d.creator_nickname, d.creator_username ? "@" + d.creator_username : ""].filter(Boolean).join(" · ");
      if (pseudo) { $("#tk-createur").textContent = `Publication sur le compte TikTok : ${pseudo}`; $("#tk-createur").hidden = false; }
      options = d.privacy_level_options || options;
      ["commentaires:comment_disabled", "duo:duet_disabled", "stitch:stitch_disabled"].forEach((paire) => {
        const [id, cle] = paire.split(":");
        const c = $("#tk-" + id);
        if (d[cle]) { c.checked = false; c.disabled = true; c.parentElement.title = "Désactivé dans tes réglages TikTok"; }
      });
    } catch (e) {
      etat.erreurCreateurTikTok = e.message;
      $("#tk-note-audit").hidden = false;
      $("#tk-note-audit").textContent = "Impossible de lire ton compte TikTok : " + e.message;
    }
  }
  etat.optionsTikTokDirect = audite ? options : ["SELF_ONLY"];
  remplirVisibiliteTikTok();
}

// Règle TikTok : liste sans choix par défaut (sauf si une seule option est possible).
function remplirVisibiliteTikTok() {
  const sel = $("#tk-visibilite");
  const options = etat.optionsTikTokDirect || ["SELF_ONLY"];
  const choisi = sel.dataset.choisi || "";  // uniquement un choix fait par l'utilisateur
  sel.innerHTML = (options.length > 1 ? '<option value="">— Choisir —</option>' : "") +
    options.map((o) => `<option value="${o}">${LIBELLES_TK[o] || o}</option>`).join("");
  if (options.length > 1) sel.value = options.includes(choisi) ? choisi : "";
  if (typeof majCommercial === "function") majCommercial();
}
$("#tk-visibilite").addEventListener("change", (e) => (e.target.dataset.choisi = e.target.value));

// ---------------------------------------------------------------- TikTok : mode d'envoi
const modeTikTok = () => ($('input[name="tk-mode"]:checked') || {}).value || "brouillon";

function majModeTikTok() {
  const mode = modeTikTok();
  const brouillon = mode === "brouillon";
  $("#tk-bloc-brouillon").hidden = !brouillon;
  $("#tk-bloc-direct").hidden = brouillon;
  const c = etat.comptes?.tiktok;
  $("#tk-note-scope").hidden = !(brouillon && c?.connecte && !c?.brouillon_autorise);
  if (mode === "direct") $("#tk-note-audit").hidden = !!c?.audite || !c?.connecte;
  remplirVisibiliteTikTok();
  memo.ecrire("tk-mode", mode);
}

async function copierLegendeTikTok(avecMessage = true) {
  const texte = $("#tk-legende").value;
  try {
    await navigator.clipboard.writeText(texte);
    if (avecMessage) toast("Légende TikTok copiée");
    return true;
  } catch {
    // Repli si le presse-papiers est refusé : sélection du texte pour Cmd+C
    $("#tk-legende").select();
    if (avecMessage) toast("Copie impossible automatiquement : la légende est sélectionnée, fais Cmd+C.", true);
    return false;
  }
}

$$('input[name="tk-mode"]').forEach((r) => r.addEventListener("change", majModeTikTok));
$("#tk-copier").addEventListener("click", () => copierLegendeTikTok());


// ---------------------------------------------------------------- TikTok : contenu commercial et déclaration (règles TikTok)
const LIEN_MUSIQUE = '<a href="https://www.tiktok.com/legal/page/global/music-usage-confirmation/en" target="_blank" rel="noopener">Music Usage Confirmation</a>';
const LIEN_MARQUE = '<a href="https://www.tiktok.com/legal/page/global/bc-policy/en" target="_blank" rel="noopener">Branded Content Policy</a>';

function commercialIncomplet() {
  return $("#tk-commercial").checked && !$("#tk-propre-marque").checked && !$("#tk-contenu-marque").checked;
}

function majCommercial() {
  const actif = $("#tk-commercial").checked;
  $("#tk-bloc-commercial").hidden = !actif;
  if (!actif) { $("#tk-propre-marque").checked = false; $("#tk-contenu-marque").checked = false; }
  const marque = $("#tk-propre-marque").checked, tiers = $("#tk-contenu-marque").checked;
  // Étiquette affichée par TikTok
  const etiquette = $("#tk-etiquette");
  etiquette.hidden = !(marque || tiers);
  etiquette.textContent = tiers ? "Ta vidéo sera étiquetée « Partenariat rémunéré »." : "Ta vidéo sera étiquetée « Contenu promotionnel ».";
  $("#tk-commercial-aide").hidden = !commercialIncomplet();
  // Le contenu de marque ne peut pas être privé
  const sel = $("#tk-visibilite");
  const prive = [...sel.options].find((o) => o.value === "SELF_ONLY");
  if (prive) { prive.disabled = tiers && sel.options.length > 1; prive.title = prive.disabled ? "Le contenu de marque ne peut pas être privé" : ""; }
  const bloqueTiers = sel.value === "SELF_ONLY";
  $("#tk-contenu-marque").disabled = bloqueTiers;
  $("#tk-lab-contenu-marque").classList.toggle("desactive", bloqueTiers);
  $("#tk-lab-contenu-marque").title = bloqueTiers ? "Le contenu de marque ne peut pas être privé : choisis une autre visibilité." : "";
  if (bloqueTiers && tiers) $("#tk-contenu-marque").checked = false;
  // Déclaration, juste avant le bouton Publier
  const decl = $("#decl-publier");
  const tiktokDirect = plateformesActives().includes("tiktok") && modeTikTok() !== "brouillon";
  decl.hidden = !tiktokDirect;
  decl.innerHTML = $("#tk-contenu-marque").checked
    ? `TikTok : en publiant, tu acceptes la ${LIEN_MARQUE} et la ${LIEN_MUSIQUE} de TikTok.`
    : `TikTok : en publiant, tu acceptes la ${LIEN_MUSIQUE} de TikTok.`;
  majResume();
}
["#tk-commercial", "#tk-propre-marque", "#tk-contenu-marque", "#tk-visibilite"].forEach((id) => $(id).addEventListener("change", majCommercial));
$$('input[name="tk-mode"]').forEach((r) => r.addEventListener("change", majCommercial));
$$(".plateforme .activer").forEach((c) => c.addEventListener("change", majCommercial));

// ---------------------------------------------------------------- publication
function verifier(actives) {
  const err = [];
  if (actives.includes("youtube") && !$("#yt-titre").value.trim()) err.push("Le titre YouTube est obligatoire.");
  if (actives.includes("tiktok")) {
    const max = etat.createurTikTok?.max_video_post_duration_sec;
    if (max && etat.dureeVideo && etat.dureeVideo > max)
      err.push(`Ta vidéo dure ${formatDuree(etat.dureeVideo)} : ton compte TikTok accepte ${Math.floor(max / 60)} min ${max % 60 ? (max % 60) + " s " : ""}au maximum.`);
    if (etat.erreurCreateurTikTok)
      err.push("TikTok ne permet pas de publier sur ce compte pour le moment : réessaie plus tard. (" + etat.erreurCreateurTikTok + ")");
  }
  if (actives.includes("tiktok") && modeTikTok() !== "brouillon") {
    if (!$("#tk-visibilite").value) err.push("Choisis qui peut voir la vidéo TikTok.");
    if (commercialIncomplet()) err.push("Contenu commercial TikTok : coche « Ta marque », « Contenu de marque », ou les deux.");
    if ($("#tk-contenu-marque").checked && $("#tk-visibilite").value === "SELF_ONLY")
      err.push("Un contenu de marque TikTok ne peut pas être privé.");
  }
  const prog = $("#yt-programmation").value;
  if (actives.includes("youtube") && prog && new Date(prog) <= new Date()) err.push("La date de programmation YouTube doit être dans le futur.");
  if (actives.includes("youtube")) { const t = traductionsPourPublication(); if (t.erreur) err.push(t.erreur); }
  return err;
}

$("#publier").addEventListener("click", async () => {
  const actives = plateformesActives();
  const erreurs = verifier(actives);
  if (erreurs.length) return toast(erreurs.join(" "), true);
  const prog = $("#yt-programmation").value;
  const tagsYt = $("#yt-tags").value.split(",").map((t) => t.trim()).filter(Boolean).concat(hashtags());
  const charge = {
    video: etat.video,
    miniature: etat.miniature,
    couverture_ms: etat.couvertureMs,
    titre: $("#titre").value.trim() || $("#yt-titre").value.trim(),
    plateformes: actives,
    youtube: {
      titre: $("#yt-titre").value.trim(),
      description: $("#yt-description").value,
      tags: [...new Set(tagsYt)],
      visibilite: $("#yt-visibilite").value,
      categorie: $("#yt-categorie").value,
      pour_enfants: $("#yt-enfants").checked,
      programmation: prog ? new Date(prog).toISOString() : null,
      traductions: traductionsPourPublication().traductions,
    },
    instagram: {
      legende: $("#ig-legende").value,
      partager_fil: $("#ig-fil").checked,
      couverture_url: $("#ig-couverture-url").value.trim() || null,
    },
    tiktok: {
      mode: modeTikTok(),
      legende: $("#tk-legende").value,
      visibilite: $("#tk-visibilite").value,
      commentaires: $("#tk-commentaires").checked,
      duo: $("#tk-duo").checked,
      stitch: $("#tk-stitch").checked,
      contenu_marque: $("#tk-contenu-marque").checked,
      propre_marque: $("#tk-propre-marque").checked,
    },
  };
  etat.derniereCharge = charge;
  etat.lignes = {};
  // Brouillon TikTok : la légende part dans le presse-papiers (le clic sur Publier l'autorise).
  if (actives.includes("tiktok") && charge.tiktok.mode === "brouillon") copierLegendeTikTok(false);
  lancer(charge);
});

async function lancer(charge) {
  try {
    const { id } = await api("/api/publier", { json: charge });
    etat.tache = id;
    majResume();
    $("#suivi").hidden = false;
    $("#nouvelle").hidden = true;
    $("#suivi h2").textContent = "Publication en cours";
    $("#suivi").scrollIntoView({ behavior: "smooth", block: "start" });
    suivre(id);
  } catch (e) {
    toast(e.message, true);
  }
}

const FINAUX = ["termine", "erreur", "avertissement"];

function afficherSuivi() {
  $("#suivi-lignes").innerHTML = Object.entries(etat.lignes).map(([p, s]) => `
    <div class="ligne-suivi ${s.etat}">
      <span class="nom-p"><i class="puce ${PUCES[p]}"></i>${NOMS[p]}</span>
      <div class="barre"><div class="barre-remplie ${s.etat === "termine" ? "ok" : s.etat === "erreur" ? "ko" : ""}" style="width:${s.etat === "erreur" ? 100 : s.progression}%"></div></div>
      <span class="message">${echapper(s.message)}${s.lien ? ` <a href="${echapper(s.lien)}" target="_blank" rel="noopener">Voir la publication ↗</a>` : ""}${
        s.etat === "erreur" && etat.tache === null ? ` <button class="lien" type="button" data-reessayer="${p}">Réessayer</button>` : ""}${
        p === "tiktok" && s.etat === "termine" && etat.derniereCharge?.tiktok?.mode === "brouillon"
          ? ` <button class="lien" type="button" data-copier>Copier la légende</button>` +
            (etat.derniereCharge.couverture_ms != null
              ? `<br>Couverture à choisir dans TikTok : image à <strong>${formatDuree(etat.derniereCharge.couverture_ms / 1000)}</strong> de la vidéo.`
              : "")
          : ""}</span>
    </div>`).join("");
  $$("[data-copier]").forEach((b) => b.addEventListener("click", () => copierLegendeTikTok()));
  $$("[data-reessayer]").forEach((b) => b.addEventListener("click", () => {
    const p = b.dataset.reessayer;
    etat.lignes[p] = { etat: "en_attente", progression: 0, message: "Nouvel essai…" };
    lancer({ ...etat.derniereCharge, plateformes: [p] });
  }));
}

async function suivre(id) {
  let t;
  try { t = await api("/api/taches/" + id); } catch (e) { toast(e.message, true); return setTimeout(() => suivre(id), 3000); }
  Object.assign(etat.lignes, t.plateformes);
  const fini = Object.values(t.plateformes).every((s) => FINAUX.includes(s.etat));
  if (fini) etat.tache = null;
  afficherSuivi();
  if (!fini) return setTimeout(() => suivre(id), 1000);
  const tousFinis = Object.values(etat.lignes).every((s) => FINAUX.includes(s.etat));
  if (tousFinis) {
    $("#suivi h2").textContent = "Publication terminée";
    $("#nouvelle").hidden = false;
  }
  majResume();
}

$("#nouvelle").addEventListener("click", () => {
  etat.video = null; etat.couvertureMs = null;
  $("#retirer-miniature").click();
  apercu.removeAttribute("src"); apercu.load();
  $("#bloc-video").hidden = true; $("#depot").hidden = false;
  $("#champ-video").value = ""; $("#capturer").disabled = true;
  ["#titre", "#description", "#yt-programmation", "#ig-couverture-url"].forEach((s) => ($(s).value = ""));
  modifies.clear(); $$(".reinit").forEach((b) => (b.hidden = true));
  trad.resultats = {}; trad.source = null; $("#tr-resultats").innerHTML = ""; majEtatTraduction();
  synchroniser();
  $("#suivi").hidden = true; $("#suivi h2").textContent = "Publication en cours";
  majMoment(); majResume();
  window.scrollTo({ top: 0, behavior: "smooth" });
});

// ---------------------------------------------------------------- historique
async function chargerHistorique() {
  const liste = $("#liste-historique");
  try {
    const h = await api("/api/historique");
    liste.innerHTML = h.length ? h.map((e) => `
      <div class="entree">
        <span class="date">${new Date(e.date).toLocaleString("fr-FR", { dateStyle: "medium", timeStyle: "short" })}</span>
        <strong>${echapper(e.titre || "Sans titre")}</strong>
        <div class="resultats">${Object.entries(e.plateformes).map(([p, s]) =>
          `<span class="etiquette ${s.etat}" title="${echapper(s.message)}"><i class="puce ${PUCES[p]}"></i>${NOMS[p]} · ${
            { termine: "publiée", avertissement: "à vérifier", erreur: "échec" }[s.etat] || s.etat}${
            s.lien ? ` <a href="${echapper(s.lien)}" target="_blank" rel="noopener">↗</a>` : ""}</span>`).join("")}</div>
      </div>`).join("") : '<p class="discret">Aucune publication pour le moment.</p>';
  } catch (e) {
    liste.innerHTML = `<p class="note erreur">${echapper(e.message)}</p>`;
  }
}

// ---------------------------------------------------------------- comptes
function afficherComptes(c) {
  etat.comptes = c;
  let manque = false;
  for (const p of ["youtube", "instagram", "tiktok"]) {
    const s = c[p];
    const txt = s.connecte ? `Connecté : ${s.compte}` : s.configure ? "Pas encore connecté" : "À configurer";
    const etatEl = $(`[data-etat="${p}"]`);
    etatEl.textContent = txt;
    etatEl.classList.toggle("ok", s.connecte);
    const badge = $(`[data-compte="${p}"]`);
    badge.textContent = s.connecte ? s.compte : "Non connecté";
    badge.classList.toggle("non", !s.connecte);
    $(`[data-deconnecter="${p}"]`).hidden = !s.connecte;
    const lien = $(`[data-connecter="${p}"]`);
    if (lien) {
      lien.classList.toggle("desactive", !s.configure);
      lien.textContent = s.connecte ? "Reconnecter" : p === "youtube" ? "Connecter ma chaîne" : "Connecter TikTok";
    }
    if (!s.connecte) manque = true;
  }
  $("#pastille-comptes").hidden = !manque;
  const cfg = c.config;
  $("#cfg-yt-id").value = cfg.youtube_client_id;
  $("#cfg-yt-secret").placeholder = cfg.youtube_secret_renseigne ? "•••••••• (enregistré)" : "";
  $("#cfg-tk-key").value = cfg.tiktok_client_key;
  $("#cfg-tk-secret").placeholder = cfg.tiktok_secret_renseigne ? "•••••••• (enregistré)" : "";
  $("#cfg-tk-redir").value = cfg.tiktok_redirect_uri;
  $("#cfg-tk-audite").checked = cfg.tiktok_audite;
  // App TikTok fournie avec l'outil : les réglages développeur restent repliés.
  $("#tk-info-app").hidden = !c.tiktok.app_fournie;
  $("#tk-avance").open = !c.tiktok.app_fournie && !c.tiktok.configure;
  $("#cfg-meta-id").value = cfg.meta_app_id || "";
  $("#cfg-meta-secret").placeholder = cfg.meta_secret_renseigne ? "•••••••• (enregistrée)" : "";
  $('[data-redir="youtube"]').textContent = c.redirections.youtube;
  $("#cfg-deepl").placeholder = cfg.deepl_renseigne ? "•••••••• (enregistrée)" : "xxxxxxxx-xxxx-…:fx";
  $('[data-etat="deepl"]').textContent = cfg.deepl_renseigne ? "Clé enregistrée" : "À configurer";
  $('[data-etat="deepl"]').classList.toggle("ok", cfg.deepl_renseigne);
  $("#tr-note-cle").hidden = cfg.deepl_renseigne;
  $("#tr-lancer").disabled = !cfg.deepl_renseigne;
  construireLangues(c.langues || {});
  majEtatTraduction();
  majResume();
  chargerCreateurTikTok();
  majModeTikTok();
}

async function chargerComptes() {
  try { afficherComptes(await api("/api/comptes")); } catch (e) { toast(e.message, true); }
}

$$("[data-enregistrer]").forEach((b) => b.addEventListener("click", async () => {
  const p = b.dataset.enregistrer;
  const corps = p === "youtube"
    ? { youtube_client_id: $("#cfg-yt-id").value, youtube_client_secret: $("#cfg-yt-secret").value }
    : p === "meta"
    ? { meta_app_id: $("#cfg-meta-id").value, meta_app_secret: $("#cfg-meta-secret").value }
    : p === "deepl"
    ? { deepl_api_key: $("#cfg-deepl").value }
    : { tiktok_client_key: $("#cfg-tk-key").value, tiktok_client_secret: $("#cfg-tk-secret").value,
        tiktok_redirect_uri: $("#cfg-tk-redir").value, tiktok_audite: $("#cfg-tk-audite").checked };
  try {
    afficherComptes(await api("/api/config", { json: corps }));
    $("#cfg-yt-secret").value = ""; $("#cfg-tk-secret").value = ""; $("#cfg-meta-secret").value = ""; $("#cfg-deepl").value = "";
    toast("Réglages enregistrés");
  } catch (e) { toast(e.message, true); }
}));

$("#connecter-ig").addEventListener("click", async () => {
  const jeton = $("#cfg-ig-jeton").value.trim();
  if (!jeton) return toast("Colle d'abord ton jeton Instagram.", true);
  try {
    afficherComptes(await api("/api/instagram/jeton", { json: { jeton } }));
    $("#cfg-ig-jeton").value = "";
    toast("Instagram connecté");
  } catch (e) { toast(e.message, true); }
});

$("#valider-tk-url").addEventListener("click", async () => {
  try {
    afficherComptes(await api("/api/tiktok/code", { json: { url: $("#tk-url-retour").value } }));
    $("#tk-url-retour").value = "";
    toast("TikTok connecté");
  } catch (e) { toast(e.message, true); }
});

$$("[data-deconnecter]").forEach((b) => b.addEventListener("click", async () => {
  const p = b.dataset.deconnecter;
  if (!confirm(`Déconnecter ${NOMS[p]} de l'outil ?`)) return;
  try { afficherComptes(await api("/api/deconnecter/" + p, { method: "POST" })); } catch (e) { toast(e.message, true); }
}));

$$(".copie code").forEach((c) => c.addEventListener("click", () => {
  navigator.clipboard?.writeText(c.textContent).then(() => toast("Adresse copiée"));
}));

// ---------------------------------------------------------------- démarrage
(function demarrer() {
  restaurerOptions();
  const modeMemo = memo.lire("tk-mode", "brouillon");
  const radio = $(`input[name="tk-mode"][value="${modeMemo}"]`);
  if (radio) radio.checked = true;
  majModeTikTok();
  $("#yt-traduire").checked = memo.lire("traduire", false);
  $("#bloc-traductions").hidden = !$("#yt-traduire").checked;
  synchroniser();
  majMoment();
  const q = new URLSearchParams(location.search);
  if (q.get("connecte")) { toast(`${NOMS[q.get("connecte")] || "Compte"} connecté`); afficherVue("comptes"); }
  if (q.get("erreur")) { toast(q.get("erreur"), true); afficherVue("comptes"); }
  if (q.toString()) history.replaceState(null, "", "/");
  chargerComptes();
})();
